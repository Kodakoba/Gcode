ENT.Type = "anim"
ENT.Base = "base_gmodentity"
 
ENT.PrintName		= "Gwa"
ENT.Author			= "Gwa"
ENT.Contact			= "Gwa"
ENT.Purpose			= "Gwa"
ENT.Instructions	= "Gwa"